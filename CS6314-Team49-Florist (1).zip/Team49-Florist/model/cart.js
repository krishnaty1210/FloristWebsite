module.exports = function Cart(cart) {
    this.items = cart.items || {};
    this.totalItems = cart.totalItems || 0;
    this.totalPrice = cart.totalPrice || 0;

    this.add = function(item, id) {
        var cartItem = this.items[id];
        if (!cartItem) {
            cartItem = this.items[id] = {item: item, quantity: 0,price: 0 };
        }
        cartItem.quantity++;
        cartItem.price = cartItem.item.price * cartItem.quantity;
        this.totalItems++;
        this.totalPrice += cartItem.item.price;
    };


    this.reduceQuantity = function (id) {
        this.items[id].quantity--;
        this.items[id].price -= this.items[id].item.price;
        this.totalItems--;
        this.totalPrice -= this.items[id].item.price;

        if(this.items[id].quantity <= 0) {
            delete this.items[id];
        }
    };

    this.addOneQuantity = function (id) {
        this.items[id].quantity++
        this.items[id].price += this.items[id].item.price;
        this.totalItems++;
        this.totalPrice += this.items[id].item.price;


    };

    this.remove = function(id) {
        this.totalItems -= this.items[id].quantity;
        this.totalPrice -= this.items[id].price;
        delete this.items[id];
    };
    
    this.itemsAll = function() {
        var my_arr = [];
        for (var id in this.items) {
            my_arr.push(this.items[id]);
        }
        return my_arr;
    };
};